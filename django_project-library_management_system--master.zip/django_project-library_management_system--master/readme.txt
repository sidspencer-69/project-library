This project Library Management System which has been developed on Python, Django and SQlite. 

A service dedicated to Admin and Student.

Only valid users will be able to access this Library Management System. Through this Books and Library Management System it will be
easy to manage accounts and various details of particular student and employees working under library along with the records of book.


For Librarian Admin Panel:
Username: adminac
Password: testing321

For Django Admin Panel:
Username: admin
Password: testing321
